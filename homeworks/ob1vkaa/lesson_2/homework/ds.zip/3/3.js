const form = document.querySelector("#comment-form");
const authorInput = document.querySelector("#author");
const textInput = document.querySelector("#text");
const comments = document.querySelector("#comments");

form.addEventListener("submit", (event) => {
  event.preventDefault();

  const author = authorInput.value.trim();
  const text = textInput.value.trim();

  if (!author || !text) return;

  const comment = createComment(author, text);
  comments.prepend(comment);

  form.reset();
});

function createComment(author, text) {
  const article = document.createElement("article");

  const name = document.createElement("h3");
  name.textContent = author;

  const message = document.createElement("p");
  message.textContent = text;

  const time = document.createElement("time");
  const now = new Date();
  time.dateTime = now.toISOString();
  time.textContent = now.toLocaleString();

  const button = document.createElement("button");
  button.textContent = "Удалить";

  button.addEventListener("click", (event) => {
    const article = event.target.closest("article");
    article.remove();
  });

  article.append(name, time, message, button);
  return article;
}
