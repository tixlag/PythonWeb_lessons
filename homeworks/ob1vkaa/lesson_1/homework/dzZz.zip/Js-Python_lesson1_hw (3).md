Ниже — 3 компактные задачи (без DOM), которые хорошо закрепят переменные/типы, современные операторы, функции, методы массивов и базовую асинхронность. Они рассчитаны на новичков в JS, но с опытом Python и верстки.

## Задача 1: «Нормализатор профиля»
Оператор optional chaining `?.` позволяет безопасно читать вложенные поля и возвращает `undefined`, если по пути встретился `null/undefined`, вместо ошибки. [developer.mozilla](https://developer.mozilla.org/ru/docs/Web/JavaScript/Reference/Operators/Optional_chaining)
Оператор `??` подставляет значение по умолчанию только когда слева `null` или `undefined` (в отличие от `||`, который реагирует на любые falsy).  [developer.mozilla](https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Operators/Nullish_coalescing)

**Дано:**
```js
const defaultUser = {
  name: "Anonymous",
  contacts: { email: "no-email@example.com" },
  settings: { theme: "light", lang: "en" },
};

const rawUsers = [
  { name: "Alice", contacts: { email: "alice@mail.com" }, settings: { theme: "dark" } },
  { contacts: {}, settings: null },
  { name: "", settings: { lang: "ru" } },
];
```

**Сделать:**
- Написать функцию `normalizeUser(raw, defaults)` (arrow function), которая возвращает **новый** объект (не мутирует `raw` и `defaults`).
- Собрать итоговый объект через `...` (spread) на верхнем уровне и для вложенных объектов (`contacts`, `settings`).
- Правила:
  - `name`: если `raw.name` равен `null/undefined` → взять дефолт; если это пустая строка `""` → оставить пустую строку (проверяется тем, что использовать нужно `??`, а не `||`).
  - `contacts.email`: безопасно прочитать через `?.`, подставить дефолт через `??`.
  - `settings.theme` и `settings.lang`: аналогично.
- Дополнительно: вывести в консоль типы (`typeof`) у `name`, `contacts`, `settings` в результате для каждого пользователя.

## Задача 2: «Мини-аналитика корзины»
**Дано:**
```js
const cart = [
  { title: "Keyboard", price: 3000, category: "tech" },
  { title: "Coffee", price: "450", category: "food" },  // строка!
  { title: "Monitor", price: 12000, category: "tech" },
  { title: "Mystery box", category: "other" },          // цены нет!
  { title: "Sticker", price: 0, category: "other" },    // нулевая цена — валидна
];
```

**Сделать:**
- Реализовать функцию `toNumberPrice(item)` (function declaration), которая возвращает **новый** объект товара, где `price` приведён к `number`, а если цены нет/она некорректна — ставит `price: null`.
- Реализовать `applyDiscount(price, discount = 10)` (arrow function), возвращающую цену со скидкой.
- Используя **только** `filter / map / reduce`, собрать объект отчёта:
  - `validItems`: только товары, у которых `price` — число (включая 0).
  - `techItems`: только `category === "tech"`.
  - `discountedTotal`: сумма всех валидных товаров после скидки 10%.
  - `maxPriceItemTitle`: название самого дорогого валидного товара.
- Условие на аккуратность: исходный `cart` после выполнения не должен измениться.

## Задача 3: «Последовательность задержек (async сценарий)»
`async function` позволяет писать promise-асинхронность в более чистом стиле, используя `await` внутри тела функции. [developer.mozilla](https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Statements/async_function)
`await` “ждёт” Promise и возвращает его результат (используется внутри `async` или на верхнем уровне модуля). [developer.mozilla](https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Operators/await)

**Дано:**
```js
const steps = [
  { label: "warmup", ms: 300 },
  { label: "work", ms: 600 },
  { label: "cooldown", ms: 300 },
];
```

**Сделать:**
- Написать `delay(ms)` → возвращает Promise, который резолвится через `ms` миллисекунд.
- Написать `runSteps(steps)` (async), которая:
  - Последовательно (именно по очереди) проходит шаги циклом `for...of`.
  - Перед ожиданием пишет: `Start <label>`, после — `End <label>`.
  - Если `ms` не число или `< 0`, шаг считается ошибочным: выбросить `Error` и поймать его в `try/catch`, вывести понятное сообщение и остановить сценарий.
- Мини-доп.: вернуть из `runSteps` массив реально выполненных `label` (чтобы было что проверить через `console.log`).

Если нужно — можно прислать, какие именно темы/строки кода студенты уже написали на практике в блоках 1–2, и задачи будут точнее под их уровень (например, добавить проверку на мутацию объектов или маленький парсер входных данных).