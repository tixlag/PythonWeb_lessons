const projects = [
  { title: "Сайт", img: "https://share.google/Wv2wL02M6Pcpee8uG", category: "web" },
  { title: "Приложение", img: "https://share.google/R4YZySJcRh3m1EUAJ", category: "mobile" },
  { title: "Лендинг", img: "https://share.google/CsJSQrac2n7RdTcrN", category: "web" },
];

const gallery = document.querySelector(".gallery");
const filters = document.querySelector(".filters");

function createProjectCard(project) {
  const figure = document.createElement("figure");
  figure.dataset.category = project.category;

  const img = document.createElement("img");
  img.src = project.img;
  img.alt = project.title;

  const figcaption = document.createElement("figcaption");
  figcaption.textContent = project.title;

  figure.append(img, figcaption);
  return figure;
}

projects.forEach(project => {
  gallery.append(createProjectCard(project));
});

filters.addEventListener("click", (event) => {
  if (!event.target.matches("button")) return;

  const category = event.target.dataset.category;
  const cards = gallery.querySelectorAll("figure");

  cards.forEach(card => {
    if (category === "all" || card.dataset.category === category) {
      card.classList.remove("hidden");
    } else {
      card.classList.add("hidden");
    }
  });
});
