const form = document.querySelector("#grade-form");
const subjectInput = document.querySelector("#subject");
const gradeInput = document.querySelector("#grade");
const list = document.querySelector("#list");
const errorBlock = document.querySelector("#error");
const averageBlock = document.querySelector("#average");

form.addEventListener("submit", (event) => {
  event.preventDefault();

  errorBlock.textContent = "";

  const subject = subjectInput.value.trim();
  const grade = Number(gradeInput.value);

  if (!subject) {
    errorBlock.textContent = "Введите название предмета";
    return;
  }

  if (!Number.isInteger(grade) || grade < 1 || grade > 5) {
    errorBlock.textContent = "Оценка должна быть числом от 1 до 5";
    return;
  }

  const li = document.createElement("li");
  li.textContent = `${subject}: ${grade}`;

  if (grade >= 4) {
    li.classList.add("good");
  } else {
    li.classList.add("bad");
  }

  list.append(li);

  updateAverage();
  form.reset();
});

function updateAverage() {
  const items = list.querySelectorAll("li");

  let sum = 0;

  items.forEach(item => {
    const grade = Number(item.textContent.split(": ")[1]);
    sum += grade;
  });

  const average = (sum / items.length).toFixed(2);
  averageBlock.textContent = `Средний балл: ${average}`;
}
