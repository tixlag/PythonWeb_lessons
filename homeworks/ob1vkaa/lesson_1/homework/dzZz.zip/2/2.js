const cart = [
  { title: "Keyboard", price: 3000, category: "tech" },
  { title: "Coffee", price: "450", category: "food" },
  { title: "Monitor", price: 12000, category: "tech" },
  { title: "Mystery box", category: "other" },
  { title: "Sticker", price: 0, category: "other" },
];

function toNumberPrice(item) {
  const price = Number(item.price);
  return {
    ...item,
    price: Number.isFinite(price) ? price : null,
  };
}

const applyDiscount = (price, discount = 10) =>
  price * (1 - discount / 100);

const validItems = cart
  .map(toNumberPrice)
  .filter(item => typeof item.price === "number");

const techItems = validItems.filter(
  item => item.category === "tech"
);

const discountedTotal = validItems.reduce(
  (sum, item) => sum + applyDiscount(item.price),
  0
);

const maxPriceItemTitle = validItems.reduce(
  (max, item) => item.price > max.price ? item : max,
  validItems[0]
).title;

const report = {
  validItems,
  techItems,
  discountedTotal,
  maxPriceItemTitle,
};

console.log(report);
