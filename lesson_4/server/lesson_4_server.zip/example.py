from http import HTTPMethod

print('Hello, World!')

