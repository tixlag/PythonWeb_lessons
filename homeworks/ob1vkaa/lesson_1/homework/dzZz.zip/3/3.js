const steps = [
  { label: "warmup", ms: 300 },
  { label: "work", ms: 600 },
  { label: "cooldown", ms: 300 },
];

const delay = (ms) => {
  return new Promise(resolve => {
    setTimeout(resolve, ms);
  });
};

const runSteps = async (steps) => {
  const done = [];

  try {
    for (const step of steps) {
      const { label, ms } = step;

      if (!Number.isFinite(ms) || ms < 0) {
        throw new Error(`Invalid delay: ${label}`);
      }

      console.log(`Start ${label}`);
      await delay(ms);
      console.log(`End ${label}`);

      done.push(label);
    }
  } catch (error) {
    console.error("Ошибка:", error.message);
  }

  return done;
};

runSteps(steps).then(result => console.log(result));
