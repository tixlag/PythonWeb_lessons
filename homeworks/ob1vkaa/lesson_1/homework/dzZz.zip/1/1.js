

const defaultUser = {
  name: "Anonymous",
  contacts: { email: "no-email@example.com" },
  settings: { theme: "light", lang: "en" },
};

const rawUsers = [
  { name: "Alice", contacts: { email: "alice@mail.com" }, settings: { theme: "dark" } },
  { contacts: {}, settings: null },
  { name: "", settings: { lang: "ru" } },
];

const normalizeUser = (raw, defaults) => {

  const result = {
    ...defaults,
    ...raw,
    name: raw.name ?? defaults.name,
    contacts: {
      ...defaults.contacts,
      email: raw.contacts?.email ?? defaults.contacts.email,
    },
    settings: {
      ...defaults.settings,
      theme: raw.settings?.theme ?? defaults.settings.theme,
      lang: raw.settings?.lang ?? defaults.settings.lang,
    },
  };

  console.log(
    typeof result.name,
    typeof result.contacts,
    typeof result.settings
  );

  return result;
};

rawUsers.map(user => normalizeUser(user, defaultUser));
